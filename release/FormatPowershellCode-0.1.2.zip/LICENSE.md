<p><a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-sa/4.0/88x31.png" /></a><br />This work is licensed under a <a rel="license" href="http://creativecommons.org/licenses/by-sa/4.0/">Creative Commons Attribution-ShareAlike 4.0 International License</a>, please attribute to Zachary Loeber and the PowerShell Community.</p>

<h6><a id="user-content-you-are-free-to" class="anchor" href="#you-are-free-to" aria-hidden="true"><span class="octicon octicon-link"></span></a>You are free to:</h6>

<p><strong>Share</strong> — copy and redistribute the material in any medium or format</p>

<p><strong>Adapt</strong> — remix, transform, and build upon the material </p>

<p>The authors encourage you to redistribute this content as widely as possible, but require that you give credit to the primary authors below, and that you notify us on github of any improvements you make.</p>