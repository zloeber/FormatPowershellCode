---
external help file: FormatPowerShellCode-help.xml
schema: 2.0.0
---

# Update-EscapableCharacters
## SYNOPSIS
Update-EscapableCharacters \[-line\] \<string\> \[\[-linetype\] \<string\>\] \[\<CommonParameters\>\]

## SYNTAX

```
Update-EscapableCharacters [-line] <String> [[-linetype] <String>]
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -line
```yaml
Type: String
Parameter Sets: (All)
Aliases: 

Required: True
Position: 0
Default value: 
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

### -linetype
```yaml
Type: String
Parameter Sets: (All)
Aliases: 

Required: False
Position: 1
Default value: 
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### System.String


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

[Online Version:]()


