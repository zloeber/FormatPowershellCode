---
external help file: FormatPowerShellCode-help.xml
schema: 2.0.0
---

# Get-BreakableTokens
## SYNOPSIS
Get-BreakableTokens \[-Tokens\] \<Token\[\]\> \[\<CommonParameters\>\]

## SYNTAX

```
Get-BreakableTokens [-Tokens] <Token[]>
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -Tokens
```yaml
Type: Token[]
Parameter Sets: (All)
Aliases: 

Required: True
Position: 0
Default value: 
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

## INPUTS

### System.Management.Automation.Language.Token[]


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

[Online Version:]()


