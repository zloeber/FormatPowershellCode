---
external help file: FormatPowerShellCode-help.xml
schema: 2.0.0
---

# Get-ParentASTTypes
## SYNOPSIS
Retrieves all parent types of a given AST element.

## SYNTAX

```
Get-ParentASTTypes [-AST] <Object>
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
Description
```

-----------

## PARAMETERS

### -AST
AST element to process.

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: True
Position: 1
Default value: 
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

## INPUTS

## OUTPUTS

## NOTES
Author: Zachary Loeber
Site: http://www.the-little-things.net/
Requires: Powershell 3.0

Version History
1.0.0 - Initial release

## RELATED LINKS

[Online Version:]()


