---
external help file: FormatPowerShellCode-help.xml
schema: 2.0.0
---

# Get-NewToken
## SYNOPSIS
Get-NewToken \[\[-line\] \<Object\>\]

## SYNTAX

```
Get-NewToken [[-line] <Object>]
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -line
{{Fill line Description}}

```yaml
Type: Object
Parameter Sets: (All)
Aliases: 

Required: False
Position: 0
Default value: 
Accept pipeline input: False
Accept wildcard characters: False
```

## INPUTS

### None


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

[Online Version:]()


