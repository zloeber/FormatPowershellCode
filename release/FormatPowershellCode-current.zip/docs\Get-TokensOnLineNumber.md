---
external help file: FormatPowerShellCode-help.xml
schema: 2.0.0
---

# Get-TokensOnLineNumber
## SYNOPSIS
Get-TokensOnLineNumber \[-Tokens\] \<Token\[\]\> \[-LineNumber\] \<int\> \[\<CommonParameters\>\]

## SYNTAX

```
Get-TokensOnLineNumber [-Tokens] <Token[]> [-LineNumber] <Int32>
```

## DESCRIPTION
{{Fill in the Description}}

## EXAMPLES

### Example 1
```
PS C:\> {{ Add example code here }}
```

{{ Add example description here }}

## PARAMETERS

### -LineNumber
```yaml
Type: Int32
Parameter Sets: (All)
Aliases: 

Required: True
Position: 1
Default value: 
Accept pipeline input: False
Accept wildcard characters: False
```

### -Tokens
```yaml
Type: Token[]
Parameter Sets: (All)
Aliases: 

Required: True
Position: 0
Default value: 
Accept pipeline input: True (ByValue)
Accept wildcard characters: False
```

## INPUTS

### System.Management.Automation.Language.Token[]


## OUTPUTS

### System.Object

## NOTES

## RELATED LINKS

[Online Version:]()


